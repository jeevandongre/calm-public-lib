from requests import Session
from json import dumps

from .blueprint import Blueprint
from .application import Application
from .util import BoundedClass


def get_handle(base, user, password, api_version=1, environment='default'):
    """Handler to get Styx handle.
    """
    styx = Styx()
    styx.create_session(base, user, password, api_version, environment)

    return styx


class Styx(object):
    """Calm class that acts as a client to the Styx API Server
    """

    @property
    def json_headers(self):
        return {'Content-type': 'application/json',
                'Accept': 'text/plain'}

    @property
    def base_api(self):
        return self.base + '/api/' + str(self.api) + '/' + self.env

    def __bind_to_session__(self):
        # Bound model classes
        klasses = [Blueprint, Application]
        for klass in klasses:
            t = BoundedClass(klass.__name__, (klass,), {'handle': self})
            setattr(self, klass.__name__, t)


    def create_session(self, base, user, password, api_version=1,
                       environment='default'):

        """Styx Constructor

        :param base: Calm base url for your calm instance. (Ex: demo.calm.io)
        :type base: String
        :param user: Calm username
        :type user: String
        :param password: Calm Password
        :type password: String
        :param api_version: Styx API Version
        :type password: Integer
        :param environment: Calm environment
        :type environment: String
        """
        self.base = base
        self.user = user
        self.password = password
        self.api = api_version
        self.env = environment
        self.rsession = Session()
        self.rsession.verify = False

        self.__bind_to_session__()

    def existing_session(self, session, base, api_version=1, environment='default'):
        self.rsession = session
        assert session.cookies is not None

        self.base = base
        self.rsession.verify = False
        self.api = 1
        self.env = environment

        user = self.get('/users/me')
        self.user = user['username']

        self.__bind_to_session__()

    def authenticate(self):
        """Authenticates the intialized user
        """
        self.auth = dumps({"username": self.user,
                           "password": self.password})

        resp = self.rsession.post(self.base_api + "/login", data=self.auth,
                                  headers=self.json_headers)

        assert resp.ok
        assert resp.cookies is not None

    def get_raw(self, url, *args, **kwargs):
        if not self.rsession.cookies:
            self.authenticate()
        return self.rsession.get(self.base_api+url, *args, **kwargs)

    def get_all(self, url, *args, **kwargs):
        """Return the response with metadata"""
        if not self.rsession.cookies:
            self.authenticate()

        resp = self.rsession.get(self.base_api+url, *args, **kwargs)

        json_resp = resp.json()
        if json_resp['code'] != 0:
            raise Exception(json_resp['message'])

        return json_resp['data']

    def get(self, url, *args, **kwargs):
        if not self.rsession.cookies:
            self.authenticate()

        resp = self.rsession.get(self.base_api+url, *args, **kwargs)

        json_resp = resp.json()
        if json_resp['code'] != 0:
            raise Exception(json_resp['message'])

        if 'row' in json_resp['data']:
            return json_resp['data']['row']
        else:
            return json_resp['data']['rows']

    def post(self, url, *args, **kwargs):
        if not self.rsession.cookies:
            self.authenticate()

        resp = self.rsession.post(self.base_api+url, *args, **kwargs)

        json_resp = resp.json()
        if json_resp['code'] != 0:
            raise Exception(json_resp['message'])

        if 'row' in json_resp['data']:
            return json_resp['data']['row']
        else:
            return json_resp['data']['rows']
