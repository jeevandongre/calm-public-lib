
def _get_user(handle, user_name):
    users = handle.get('/users?username=%s' % user_name)
    user = [t for t in users if t['username'] == user_name]

    if user:
        return user[0]
    else:
        raise Exception("User not found")


def _get_team(handle, team_name):
    teams = handle.get('/teams?name=%s' % team_name)
    team = [t for t in teams if t['name'] == team_name]

    if team:
        return team[0]
    else:
        raise Exception("Team not found")


def _get_budget(handle, budget_name):
    budgets = handle.get('/budgets?name=%s' % budget_name)
    budget = [t for t in budgets if t['name'] == budget_name]

    if budget:
        return budget[0]
    else:
        raise Exception("Budget not found")


def _get_namespaced_prop_list(blueprint_json):
    props = {'blueprint': blueprint_json['properties']}

    resource_props = []
    for resource in blueprint_json['architecture']:
        resource_props.append({resource['name']: resource['properties']})

    props['resources'] = resource_props

    return props


def _merge_runtime_props(blueprint, prop_list=[], async=True):
    """Parse a given proplist and update the blueprint json in place. The proplist
    contains a list of strings.

    Each string is of the form:

        "<BLUEPRINT_PROP_NAME>=<BLUEPRINT_PROP_VAL>"
        eg:
           "blueprint_prop_1=val1"

    OR

        "<RESOURCE_NAME>:<RESOURCE_PROP_NAME>=<RESOURCE_PROP_VAL>"
        eg:
           "Resource_1:rc_prop=rc_prop_val"

    """

    if not prop_list:
        return

    for prop in prop_list:
        prop_key, prop_val = prop.split('=')

        prop_key = prop_key.rstrip()
        prop_val = prop_val.lstrip()

        if ':' not in prop_key:  # Blueprint Properties
            for bp_prop in blueprint['properties']:
                if bp_prop['key'] == prop_key:
                    bp_prop['value'] = prop_val
        else:
            resource_name, prop_name = prop_key.split(':')
            if not resource_name and prop_name:
                raise Exception("Resource name/Property name cannot be empty")

            for resource in blueprint['architecture']:
                if resource['name'] == resource_name:
                    for resource_prop in resource['properties']:
                        if resource_prop['key'] == prop_name:
                            resource_prop['value'] = prop_val


class Blueprint(object):

    url = '/blueprints'
    ACTIVE = 'ACTIVE'
    data = {}

    def __init__(self, blueprint_data):
        self.data = blueprint_data
        self.url = self.__class__.url + '/' + blueprint_data['uid']

    def __repr__(self):
        return "<Blueprint: %s, UID: %s>" % (self.name, self.uid)

    @property
    def uid(self):
        return self.data.get('uid')

    @property
    def name(self):
        return self.data['name']

    @classmethod
    def get(cls, blueprint_name, include_deactivated=False):
        params = {"name": blueprint_name}

        if not include_deactivated:
            params['status'] = Blueprint.ACTIVE

        blueprints = cls.handle.get("/blueprints", params=params)

        blueprint_id = None
        for blueprint in blueprints:
            if blueprint['name'] == blueprint_name:
                blueprint_id = blueprint['uid']
                break

        if not blueprint_id:
            raise Exception("Blueprint not found!")

        blueprint = cls.handle.get("/blueprints/%s/run" % blueprint_id)

        return cls(blueprint)

    @classmethod
    def list(cls, params={}):
        return cls.handle.get("/blueprints", params=params)

    def run(self, app_name, team_name, budget_name=None, prop_list=[]):
        """Creates an application from a blueprint.
        """

        user = _get_user(self.handle, self.handle.user)
        team = _get_team(self.handle, team_name)

        if user['uid'] not in team['users']:
            raise Exception("User is not part of the team")

        budget = None
        if budget_name:
            budget = _get_budget(self.handle, budget_name)

        if budget and budget['team'] != team['uid']:
            raise Exception("Team does not have access to the budget")

        # TODO: Add other budget checks!

        blueprint = self.data
        blueprint['name'] = app_name
        blueprint['team_id'] = team['uid']
        blueprint['budget_id'] = budget['uid'] if budget else None
        blueprint['id'] = 'cid:xxxxxxxx'

        for cred in blueprint['credentials']:
            cred['secret'] = None

        _merge_runtime_props(blueprint, prop_list)

        result = self.handle.post("/blueprints/%s/run" % blueprint['uid'],
                                  json=blueprint)

        return self.handle.Application(result)

    def delete(self):
        self.handle.post("/blueprints/%s/delete" % self.uid)

    def download(self):
        resp = self.handle.get_raw("/download/blueprints/%s" % self.uid)

        if resp.status_code != 200:
            raise Exception("Blueprint download failed. Server returned %s", resp.status_code)

        file_name = self.name + '.json'

        with open(file_name, 'w') as out_file:
            out_file.write(resp.content)

        print "Blueprint file %s created" % file_name

    @classmethod
    def upload(cls, blueprint_name, file_path):
        cls.handle.post("/upload/blueprints",
                        files={'upload_file': open(file_path)},
                        data={'blueprint_name': blueprint_name})
        return cls.get(blueprint_name)
