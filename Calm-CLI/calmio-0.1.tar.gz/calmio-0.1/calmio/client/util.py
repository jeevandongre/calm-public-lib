class BoundedClass(type):
    """Meta class for getting bound resources to a session."""

    def __new__(cls, classname, bases, class_dict):
        """
        :param parent handle: Parent class onto which the resource is bound to
        """
        class_dict['handle'] = class_dict.get('handle', None)
        return super(BoundedClass, cls) \
            .__new__(cls, classname, bases, class_dict)
