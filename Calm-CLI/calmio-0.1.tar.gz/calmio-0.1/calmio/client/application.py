from time import sleep


class Application(object):

    url = '/applications'
    TERMINAL_STATES = ['SUCCESS', 'FAILURE', 'DELETED']
    data = {}

    def __init__(self, application_data):
        self.data = application_data
        self.url = self.__class__.url + '/' + application_data['uid']

    def __repr__(self):
        return "<Application: %s, UID: %s>" % (self.name, self.uid)

    def machine_status(self):
        return self.handle.get_all(
            '/applications/%s/machine_status?state__ne=DELETED'
            % self.uid)

    def join(self):
        """Wait for application to reach a terminal state"""
        while True:
            sleep(2)

            status = self.machine_status()
            yield status

            if status['application_state'] in self.TERMINAL_STATES:
                raise StopIteration

    @property
    def uid(self):
        return self.data['uid']

    @property
    def name(self):
        return self.data['name']

    @classmethod
    def get(cls, application_name):
        params = {"name": application_name}

        applications = cls.handle.get("/applications", params=params)

        application_id = None
        for application in applications:
            if application['name'] == application_name:
                application_id = application['uid']
                break

        if not application_id:
            raise Exception("Application not found!")

        application = cls.handle.get("/applications/%s" % application_id)

        return cls(application)

    @classmethod
    def list(cls, params={}):
        return cls.handle.get("/applications", params=params)

    def delete(self):
        self.handle.post("/applications/%s/delete" % self.uid)
