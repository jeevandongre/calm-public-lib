#!/usr/bin/env python

from ConfigParser import ConfigParser
from argparse import ArgumentParser
from cookielib import LWPCookieJar
from os.path import expanduser, join
from tabulate import tabulate
from collections import defaultdict, OrderedDict
import requests

from .client import get_handle

calm_home = join(expanduser('~'), '.calm')
calm_config_file = join(calm_home, 'config')
calm_auth_cache = join(calm_home, 'cache')
calm_session = requests.Session()
calm_session.cookies = LWPCookieJar(calm_auth_cache)

# TODO
_config = ConfigParser()
_config.read(calm_config_file)

calm_host = _config.get('calm', 'host')
calm_user = _config.get('calm', 'username')
calm_pass = _config.get('calm', 'password')
calm_api_version = _config.get('calm', 'api_version')
calm_default_environment = _config.get('calm', 'default_environment')

calm_handle = get_handle(calm_host, calm_user, calm_pass, calm_api_version,
                         calm_default_environment)


def _print_blueprint_list(blueprints):
    blueprint_data = defaultdict(list)

    for d in blueprints:
        for k, v in d.items():
            blueprint_data[k].append(v)

    ordered_label_mapper = [
        {'key': 'uid', 'label': 'Blueprint ID'},
        {'key': 'name', 'label': 'Name'},
        {'key': 'status', 'label': 'Status'},
        {'key': 'application_count', 'label': 'Application Count'},
        {'key': 'created_by_user_name', 'label': 'Created By'}]

    blueprint_pretty_data = OrderedDict()
    for c in ordered_label_mapper:
        blueprint_pretty_data[c['label']] = blueprint_data[c['key']]

    print tabulate(blueprint_pretty_data, tablefmt='grid', headers='keys')


def _print_application_list(applications):
    application_data = defaultdict(list)

    for d in applications:
        for k, v in d.items():
            application_data[k].append(v)

    ordered_label_mapper = [
        {'key': 'uid', 'label': 'Application ID'},
        {'key': 'name', 'label': 'Name'},
        {'key': 'state', 'label': 'State'},
        {'key': 'created_by_user_name', 'label': 'Created By'}]

    application_pretty_data = OrderedDict()
    for c in ordered_label_mapper:
        application_pretty_data[c['label']] = application_data[c['key']]

    print tabulate(application_pretty_data, tablefmt='grid', headers='keys')


def test_login(args):
    try:
        calm_handle.authenticate()
        print "Login Successful"
        exit(0)
    except Exception:
        print "Login Failed"
        exit(1)


def list_blueprint(args):
    params = {}
    if args.query:
        for query in args.query:
            try:
                key, val = query.split('=')
            except ValueError:
                continue

            val = val.upper() if key == 'state' else val

            key = key.strip()
            val = val.strip()

            if key in ['name', 'status']:
                params[key] = val

    try:
        blueprints = calm_handle.Blueprint.list(
            params=dict(params, **{'limit': 9999,
                                   'offset': 0,
                                   'sort_by': 'creation_time',
                                   'sort_order': 'desc'}))
        _print_blueprint_list(blueprints)
        return 0
    except Exception:
        print "Failed getting list of blueprints"


def run_blueprint(args):
    try:
        blueprint = calm_handle.Blueprint.get(args.blueprint_name)
        print "Blueprint %s found with ID: %s" % (blueprint.name, blueprint.uid)

        app = blueprint.run(args.app_name,
                            team_name=args.team_name,
                            budget_name=args.budget_name,
                            prop_list=args.prop_list)
        print "Application created with ID: %s" % app.uid

        if not args.async:
            print "Polling for application state: "
            for status in app.join():
                state = status['application_state']
                print " - Application State: %s" % state
            return 0

    except Exception as e:
        print e.message
        return 1


def delete_blueprint(args):
    try:
        blueprint = calm_handle.Blueprint.get(args.blueprint_name)
        print "Blueprint %s found with ID: %s" % (blueprint.name, blueprint.uid)
        blueprint.delete()
        print "Blueprint Deleted"
        return 0
    except Exception as e:
        print e.message
        return 1


def download_blueprint(args):
    try:
        blueprint = calm_handle.Blueprint.get(args.blueprint_name,
                                              include_deactivated=True)
        print "Blueprint %s found with ID: %s" % (blueprint.name,
                                                  blueprint.uid)
        blueprint.download()
        return 0
    except Exception as e:
        print e.message
        return 1


def upload_blueprint(args):
    try:
        blueprint = calm_handle.Blueprint.upload(args.blueprint_name,
                                                 args.blueprint_file)
        print "Blueprint %s created with ID %s" % (blueprint.name, blueprint.uid)
        return 0
    except Exception as e:
        print e.message
        return 1


def list_application(args):
    params = {}

    if args.query:
        for query in args.query:
            try:
                key, val = query.split('=')
            except ValueError:
                continue
            val = val.upper() if key == 'state' else val

            key = key.strip()
            val = val.strip()

            if key in ['name', 'state']:
                params[key] = val

    try:
        applications = calm_handle.Application.list(
            params=dict(params, **{'limit': 9999,
                                   'offset': 0,
                                   'sort_by': 'creation_time',
                                   'sort_order': 'desc'}))
        _print_application_list(applications)
        return 0
    except Exception:
        print "Failed getting list of applications"
    pass


def delete_application(args):
    try:
        application = calm_handle.Application.get(args.application_name)
        print "Application %s found with ID: %s" % (application.name, application.uid)
        application.delete()
        print "Application Deleted"
        return 0
    except Exception as e:
        print e.message
        return 1


def main():
    parser = ArgumentParser(
        description="CLI for calm @ %s" % calm_handle.base,
        epilog="Using config file at %s" % calm_config_file)

    subparsers = parser.add_subparsers()

    parser_test_login = subparsers.add_parser('test-login', help='Test Login')
    parser_test_login.set_defaults(func=test_login)

    parser_blueprint = subparsers.add_parser('blueprint', help='Blueprint Commands')
    subparser_blueprint = parser_blueprint.add_subparsers(title='subcommands',
                                                          help='Blueprint sub-command to run')

    blueprint_list = subparser_blueprint.add_parser(
        'list', help='List of blueprints',
        usage='calm blueprint list -q name=abc status=[active/deactivated/draft]')
    blueprint_list.add_argument('-q', '--query', help='Query conditions',
                                dest='query', nargs='+')
    blueprint_list.set_defaults(func=list_blueprint)

    blueprint_run = subparser_blueprint.add_parser(
        'run', help='Run Blueprint',
        usage='calm blueprint run -b <BLUEPRINT_NAME> -a <APPLICATION_NAME> -t <TEAM_NAME> --budget <BUDGET_NAME> --props <BLUEPRINT_PROP_NAME=VALUE> <RC_NAME:RC_PROP_NAME=VALUE> --async')
    blueprint_run_req = blueprint_run.add_argument_group(
        title='Blueprint Run Required Arguments')
    blueprint_run_req.add_argument('-b', '--blueprint', dest='blueprint_name',
                                   metavar='Blueprint Name', required=True)
    blueprint_run_req.add_argument('-a', '--application', dest='app_name',
                                   metavar='Application Name', required=True)
    blueprint_run_req.add_argument('-t', '--team', dest='team_name',
                                   metavar='Team Name', required=True)

    blueprint_run_opt = blueprint_run.add_argument_group(
        title='Blueprint Run Optional Arguments')

    blueprint_run_opt.add_argument('--budget', dest='budget_name',
                                   metavar='Budget Name')
    blueprint_run_opt.add_argument('--props', dest='prop_list',
                                   metavar='Runtime Properties List', nargs='+')
    blueprint_run_opt.add_argument('--async', action='store_true', dest='async')
    blueprint_run.set_defaults(func=run_blueprint)

    blueprint_delete = subparser_blueprint.add_parser('delete', help='Delete Blueprint')
    blueprint_delete.add_argument('-b', '--blueprint', dest='blueprint_name',
                                   metavar='Blueprint Name', required=True)
    blueprint_delete.set_defaults(func=delete_blueprint)

    blueprint_download = subparser_blueprint.add_parser('download', help='Download Blueprint')
    blueprint_download.add_argument('-b', '--blueprint', dest='blueprint_name',
                                   metavar='Blueprint Name', required=True)
    blueprint_download.set_defaults(func=download_blueprint)

    blueprint_upload = subparser_blueprint.add_parser('upload', help='Upload Blueprint')
    blueprint_upload.add_argument('-n', '--blueprint-name', dest='blueprint_name',
                                   metavar='Blueprint Name', required=True)
    blueprint_upload.add_argument('-f', '--file', dest='blueprint_file',
                                   metavar='Blueprint File', required=True)
    blueprint_upload.set_defaults(func=upload_blueprint)

    parser_application = subparsers.add_parser('application', help='Application Commands')
    subparser_application = parser_application.add_subparsers(
        title='subcommands', help='Application sub-command to run')

    application_list = subparser_application.add_parser(
        'list', help='List of applications',
        usage='calm application list -q name=abc status=[pending/running/success/failure/deleted]')

    application_list.add_argument('-q', '--query', help='Query conditions',
                                  dest='query', nargs='+')
    application_list.set_defaults(func=list_application)

    application_delete = subparser_application.add_parser('delete', help='Delete Application')
    application_delete.add_argument('-a', '--application', dest='application_name',
                                    metavar='Application Name', required=True)
    application_delete.set_defaults(func=delete_application)

    args = parser.parse_args()
    code = args.func(args)
    return code
