from setuptools import setup, find_packages
from codecs import open
from os import path

setup(
    name='calmio',
    version='0.1',
    description='calm.io client package and CLI tool',
    url='https://github.com/ideadevice/calm-cli',
    author='Calm Dev',
    author_email='dev@calm.io',
    license='MIT',

    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Calm.io customers',
        'Topic :: Software Development :: CLI Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2.7',
    ],

    keywords='calm.io cli',

    packages=find_packages(),

    install_requires=['requests', 'tabulate==0.7.5'],

    data_files=[(path.join(path.expanduser('~'), '.calm'),
                 ['config'])],

    entry_points={
        'console_scripts': [
            'calm=calmio.cli:main',
        ],
    }
)
